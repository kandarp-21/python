Lucky_Cards=['Spade Of Ace','Heart','Queen Of Diamond','King Of Diamond','7']
card=input("Enter card : (Ex. Spade Of 2)")
if card in Lucky_Cards:
    print("Lucky you!")
elif "Heart" in card :
    print("Lucky you!")
else :
    print("Better luck next time.")